// Produced by makever.pl.  Don't edit.
#define VER_MAJOR 0
#define VER_MINOR 3
#define VER_BUILD 7
#define VER_BUILD_TIME 1391109770
#ifndef STRINGIFY
#define ___S(X) #X
#define STRINGIFY(X) ___S(X)
#endif
#define VER_BUILD_TIME_STRING STRINGIFY(Thu Jan 30 14:22:50 2014)
#define VER_STRING STRINGIFY(VER_MAJOR) "." STRINGIFY(VER_MINOR) " (build " STRINGIFY(VER_BUILD) "d, " VER_BUILD_TIME_STRING ")"
